package com.hsm.serviceImpl;

import com.hsm.entity.Appointment;
import com.hsm.entity.Doctor;
import com.hsm.repository.AppointmentRepository;
import com.hsm.service.AppointmentService; // Make sure to import the correct interface
import com.hsm.service.DoctorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AppointmentServiceImpl implements AppointmentService { // Implement the correct interface

    private final AppointmentRepository appointmentRepository;

    @Autowired
    public DoctorService doctorService;
    
    
    @Autowired
    public AppointmentServiceImpl(AppointmentRepository appointmentRepository) {
        this.appointmentRepository = appointmentRepository;
    }

    @Override
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    @Override
    public Optional<Appointment> getAppointmentById(Long id) {
        return appointmentRepository.findById(id);
    }

    @Override
    public Appointment createAppointment(Appointment appointment, long doctorId) {
    	Doctor doctor = doctorService.getDoctorById(doctorId);
    	appointment.setDoctName(doctor.getDoctName());
    	appointment.setDoctorId(doctorId);
        return appointmentRepository.save(appointment);
    }

  
    @Override
    public Appointment updateAppointment(Long id, Appointment updatedAppointment) {
        // Check if the appointment with the given ID exists
        if (appointmentRepository.existsById(id)) {
            updatedAppointment.setAppointmentId(id);
            return appointmentRepository.save(updatedAppointment);
        }
        return null; // Handle error appropriately
    }

    
    
    
    @Override
    public boolean deleteAppointment(Long id) {
        if (appointmentRepository.existsById(id)) {
            appointmentRepository.deleteById(id);
            return true;
        }
        return false; // Handle error appropriately
    }

	@Override
	public List<Appointment> getAppointmentByDoctorId(long doctorId) {
		// TODO Auto-generated method stub
		return appointmentRepository.findByDoctorId(doctorId);
	}

	@Override
	public Appointment createAppointment(Appointment appointment) {
		// TODO Auto-generated method stub
		 return appointmentRepository.save(appointment);
	}

	@Override
	public int countOfAppointmentByDoctorId(long doctor_id) {
		// TODO Auto-generated method stub
		return appointmentRepository.findCountOfAppointmentByDoctorId(doctor_id);
	}

	@Override
	public int countOfAllAppointmentById(long admin_id) {
		// TODO Auto-generated method stub
		return appointmentRepository.findCountOfAllAppointmentById(admin_id);
	}


	
}
