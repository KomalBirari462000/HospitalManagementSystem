package com.hsm.serviceImpl;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hsm.repository.*;
import com.hsm.entity.*;
import com.hsm.service.DoctorService;


@Service
public class DoctorImpl implements DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;
    

    
//    @Autowired
//    private AppointmentRepository appointmentRepository;


    @Override
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    @Override
    public Doctor getDoctorById(Long id) {
        return doctorRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteDoctor(Long id) {
        doctorRepository.deleteById(id);
    }

	@Override
	public List<Patient> getDoctorPatients(Long doctorId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <Bill> Bill generateBill(Patient patient, double amount) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
    public Doctor addDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }

	@Override
	public Doctor findDoctorByEmailAndPassword(Doctor doctor) {
		// TODO Auto-generated method stub
		System.out.println("inside doctor service");
		return doctorRepository.findByEmailAndPassword(doctor.getEmail(), doctor.getPassword());
		
	}

	@Override
	public Doctor updateDoctorList(Doctor updateDoctor) {
		// TODO Auto-generated method stub
		getDoctorById(updateDoctor.getDoctorId());
		return doctorRepository.save(updateDoctor);
	}



    
}
