package com.hsm.serviceImpl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hsm.entity.Patient;
import com.hsm.repository.PatientRepository;
import com.hsm.service.PatientService;


@Service
public class PatientImpl implements PatientService {

	@Autowired
	 private PatientRepository patientRepository;
	
	//Default Constructor
	public PatientImpl() {
		
	}

	//Get list of all Patients
	@Override
	public List<Patient> getPatient() {
		// TODO Auto-generated method stub
		return patientRepository.findAll();
	}

	@Override
	public Patient getPatientById(long id) {
		// TODO Auto-generated method stub
		Optional<Patient> optionalPatient = patientRepository.findById(id);
        return optionalPatient.orElse(null);
	}

	   @Override
	    public void addPatient(Patient patient) {
	        patientRepository.save(patient);
	    }

	@Override
	public void updatePatient(Patient patient) {
		// TODO Auto-generated method stub
		patientRepository.save(patient);
	}

	@Override
	public void deletePatient(long id) {
		// TODO Auto-generated method stub
		patientRepository.deleteById(id);
	}
	
	

	@Override
	public void loginPatient(Patient patient) {
		// TODO Auto-generated method stub
		
	}

	@Override
    public void loginPatient(String email, String password) {
        // Find the patient by email (assuming email is unique)
        Optional<Patient> optionalPatient = patientRepository.findByEmailId(email);

        if (optionalPatient.isPresent()) {
            Patient patient = optionalPatient.get();

            // Compare the provided password with the stored password (you may need to hash the password)
            if (password.equals(patient.getPassword())) {
                // Login successful, you can perform any required actions here
                System.out.println("Login successful");
            } else {
                // Incorrect password
                System.out.println("Login failed: Incorrect password");
            }
        } else {
            // Patient with the given email does not exist
            System.out.println("Login failed: Patient not found");
        }
    }

	@Override
	public Patient findByEmailIdAndPassword(Patient patient) {
		// TODO Auto-generated method stub
		System.out.println("inside patient service");
		Patient patient1 =  patientRepository.findByEmailIdAndPassword(patient.getEmailId(), patient.getPassword()) ;
		System.out.println(patient1);
		return patient1;
	}
	
}
