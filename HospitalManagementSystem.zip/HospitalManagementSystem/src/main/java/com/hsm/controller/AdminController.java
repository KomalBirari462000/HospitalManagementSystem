package com.hsm.controller;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hsm.service.AdminService;
import com.hsm.entity.Admin;


@RestController
@RequestMapping("/admin")
@CrossOrigin("*")
public class AdminController {

    @Autowired
    private AdminService adminService;
    
 // GET Request to retrieve a list of all Admins
    @GetMapping("/all")
    public ResponseEntity<List<Admin>> getAllAdmins() {
        // Call the service to retrieve all Admins
        List<Admin> admins = adminService.getAllAdmins();

        if (!admins.isEmpty()) {
            // Return the list of Admins with HTTP status OK (200)
            return new ResponseEntity<>(admins, HttpStatus.OK);
        } else {
            // Return HTTP status NOT FOUND (404) if no Admins were found
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // GET Request to retrieve an Admin by ID
    @GetMapping("/{id}")
    public ResponseEntity<Admin> getAdmin(@PathVariable Long id) {
        Admin admin = adminService.getAdminById(id);
        if (admin != null) {
            return new ResponseEntity<>(admin, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

 // POST Request to create a new Admin
    @PostMapping("/")
    public ResponseEntity<Admin> createAdmin(@RequestBody Admin admin) {
        Admin createdAdmin = adminService.createAdmin(admin);
        return new ResponseEntity<>(createdAdmin, HttpStatus.CREATED);
    }
    
    //admin login
    @PostMapping("/login")
    public ResponseEntity<Admin> adminLogin(@RequestBody Admin admin) {
    	System.out.println("inside admin login" + admin);
        Admin adminLogin = adminService.findAdminByUserNameAndPassword(admin);
        return new ResponseEntity<>(adminLogin, HttpStatus.CREATED);
    }

 // PUT Request to update an existing Admin by ID
    @PutMapping("/update/{id}")
    public ResponseEntity<Admin> updateAdmin(@PathVariable Long id, @RequestBody Admin admin) {
        Admin updatedAdmin = adminService.updateAdmin(id, admin);
        if (updatedAdmin != null) {
            return new ResponseEntity<>(updatedAdmin, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

 // DELETE Request to delete an Admin by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteAdmin(@PathVariable Long id) {
    	 if (adminService.deleteAdmin(id)) {
             // Return HTTP status NO CONTENT (204) if Admin was successfully deleted
             return new ResponseEntity<>(HttpStatus.NO_CONTENT);
         } else {
             // Return HTTP status NOT FOUND (404) if Admin was not found
             return new ResponseEntity<>(HttpStatus.NOT_FOUND);
         }
  
    }
   
}
