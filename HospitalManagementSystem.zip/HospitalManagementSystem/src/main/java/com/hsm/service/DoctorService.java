package com.hsm.service;

import java.util.List;

import com.hsm.entity.Doctor;
import com.hsm.entity.Patient;

public interface DoctorService {

    Doctor addDoctor(Doctor doctor);

    //List<Doctor> addDoctors(List<Doctor> doctors);

    List<Doctor> getAllDoctors();

    Doctor getDoctorById(Long id);

    void deleteDoctor(Long id);

    List<Patient> getDoctorPatients(Long doctorId);

	<Bill> Bill generateBill(Patient patient, double amount);

	Doctor findDoctorByEmailAndPassword(Doctor doctor);

	Doctor updateDoctorList(Doctor updateDoctor);

	
	
    
}
