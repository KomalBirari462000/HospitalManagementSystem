package com.hsm.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hsm.entity.Admin;

@Service
public interface AdminService {

	Admin createAdmin(Admin admin);

	Admin getAdminById(Long id);

	Admin updateAdmin(Long id, Admin updatedAdmin);

	boolean deleteAdmin(Long id);

	List<Admin> getAllAdmins();
	
	Admin findAdminByUserNameAndPassword(Admin admin);
	
}
