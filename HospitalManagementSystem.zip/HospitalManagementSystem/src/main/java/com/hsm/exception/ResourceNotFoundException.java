package com.hsm.exception;

public class ResourceNotFoundException extends Exception{

	public ResourceNotFoundException() {
        super("User with this username not found in database !!");
    }

    public ResourceNotFoundException(String msg) {
        super(msg);
    }
}
